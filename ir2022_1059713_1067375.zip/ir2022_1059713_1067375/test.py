import pandas as pd
# Paths
INPUT_FILES = "Files/Input/"

USERS = INPUT_FILES + "BX-Users.csv"
RATINGS = INPUT_FILES + "BX-Book-Ratings.csv"
BOOKS = INPUT_FILES + "BX-Books.csv"

users = pd.read_csv(USERS)
ratings = pd.read_csv(RATINGS)

asd = pd.merge(left=users, right=ratings, on="uid").groupby("uid").count().sort_values(by="rating", ascending=False)
print(asd.head())