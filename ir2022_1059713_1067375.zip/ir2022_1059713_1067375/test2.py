import pandas as pd
d1 = {'vectors': [['0.1', '0.2', '0.3', '0.4', '0.5'], ['0.1', '0.2', '0.3', '0.4', '0.5'], ['0.1', '0.2', '0.3', '0.4', '0.5'],
    ['0.1', '0.2', '0.3', '0.4', '0.5'], ['0.1', '0.2', '0.3', '0.4', '0.5'], ['0.1', '0.2', '0.3', '0.4', '0.5']]}
df2 = pd.DataFrame(d1)
print (df2)

vect_list = df2.vectors.tolist()
df2[["vect"+str(i) for i in range(len(vect_list[0]))]] = pd.DataFrame(vect_list, index= df2.index)
print (df2) 
print(["vect"+str(i) for i in range(10)])