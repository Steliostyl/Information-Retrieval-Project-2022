import pandas as pd
PROCESSED_FILES = "Files/Processed/"
BOOKS_VECTORIZED_SUMMARIES_PKL = PROCESSED_FILES + "Books-Vectorized-Summaries.pkl"

books = pd.read_pickle(BOOKS_VECTORIZED_SUMMARIES_PKL)
print(len(books.columns.values) - 1)
col_list = list(books.columns.values)

col_list.pop(-1)
print(col_list)